bl_info = {
    "name": "EasyFluid",
    "author": "Aaranyak",
    "version": (4, 0),
    "blender": (2, 82, 0),
    "location": "3d View > Header, or 3d View > Side Panel > EasyFluid",
    "description": "Fluid Simulations in just 2 clicks!",
    "warning": "All bugs not yet fixed. Having some problems with guides",
    "tracker_url": "https://mail.google.com/mail/u/0/?view=cm&fs=1&tf=1&to=aaranyak.ghosh@nextschool.org+jeta.gaikwad@nextschool.org&su=Bug+Report&body=Dear+EasyFluid+Developers%0AI+want+to+report+a+bug%0AThis+bug+happens+in+the+Preferences/3d+View/Side+panel%0A%0A--Description--%0A%0A%0APlease+try+to+fix+this+bug%0AFrom%0A--Name--%0A%0Ahttps://docs.google.com/document/d/111R0Vf4Z8N9JasQxrbn_1FY6cg0vBxB0c6U_NXYHgOY/edit?usp=sharing",
    "doc_url": "https://docs.google.com/document/d/111R0Vf4Z8N9JasQxrbn_1FY6cg0vBxB0c6U_NXYHgOY/edit?usp=sharing",
    "category": "Object",
}
import bpy

#==========================Operators==============================#
bpy.types.Scene.AddonLocup = 'HEAD'
bpy.types.Scene.EffPanup = True
bpy.types.Scene.LiqPanup = True

def AddLocChange(self,context):
    scene = context.scene
    if scene is not None:
        bpy.types.Scene.AddonLocup = scene.AddonLoc
        if bpy.types.Scene.AddonLocup == 'ADD':
            bpy.types.VIEW3D_MT_mesh_add.remove(add_menu_fluid)
            bpy.types.VIEW3D_HT_header.remove(add_menu_fluid)
            bpy.types.VIEW3D_MT_mesh_add.append(add_menu_fluid)
        elif bpy.types.Scene.AddonLocup == 'HEAD':
            bpy.types.VIEW3D_MT_mesh_add.remove(add_menu_fluid)
            bpy.types.VIEW3D_HT_header.remove(add_menu_fluid)
            bpy.types.VIEW3D_HT_header.append(add_menu_fluid)
def EffPanChange(self,context):
    scene = context.scene
    if scene is not None:
        bpy.types.Scene.EffPanup = scene.EffectorBol
        if scene.LiqPanup:
            bpy.utils.register_class(EffectorPanel)
        if not scene.EffPanup:
            bpy.utils.unregister_class(EffectorPanel)
def LiqPanChange(self,context):
    scene = context.scene
    if scene is not None:
        bpy.types.Scene.LiqPanup = scene.LiquidBol
        if scene.LiqPanup:
            bpy.utils.register_class(EasyLiquidPanel)
        if not scene.LiqPanup:
            bpy.utils.unregister_class(EasyLiquidPanel)





bpy.types.Scene.AddonLoc = bpy.props.EnumProperty(
    name = "Addon Location",
    items = [("HEAD","Header","Top of the 3d View"),("ADD","Add Mesh","In the add mesh menu")],
    default = "HEAD",
    description = "Where to find the addon menu",
    update = AddLocChange

)
bpy.types.Scene.EffectorBol = bpy.props.BoolProperty(
    name = "Effector Panel",
    default = True,
    description = "A panel for effectors",
    update = EffPanChange
)
bpy.types.Scene.LiquidBol = bpy.props.BoolProperty(
    name = "EasyLiquid Panel",
    default = True,
    description = "A panel for liquids",
    update = LiqPanChange
)

class EasyFluidPreferences(bpy.types.AddonPreferences):
    # this must match the add-on name, use '__package__'
    # when defining this in a submodule of a python package.
    bl_idname = __package__

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        layout.label(text="Easy Fluid",icon='MOD_FLUIDSIM')
        row = layout.row()
        layout.label(text="This is an addon that simplifies fluid simulations",icon='MOD_OCEAN')
        row = layout.row()
        layout.label(text="To find this addon,")
        row = layout.row()
        layout.label(text="Go to the 3d view and look in the header find a menu marked EasyFluid",icon='SCENE_DATA')

        row = layout.row()
        layout.label(text="EasyLiquid creates a liquid simulation by using the selected object as a flow",icon='MOD_FLUID')

        row = layout.row()
        layout.label(text="")

        row = layout.row()
        layout.label(text="This menu creates effectors",icon='MATSHADERBALL')

        row = layout.row()
        layout.label(text="The flow controller makes the fluid follow the controller",icon='ANIM')

        row = layout.row()
        layout.label(text="The Collision makes the fluid collide with the object",icon='MOD_MASK')
        scene = context.scene
        row = layout.row()
        layout.label(text = "")
        layout.label(text="Addon Preferences",icon='SETTINGS')
        row = layout.row()
        layout.label(text="Addon Location")
        row = layout.row()
        row.prop(scene,"AddonLoc",expand=True)
        row = layout.row()
        row.prop(scene,'EffectorBol',toggle=True,icon='MATSHADERBALL')
        row = layout.row()
        row.prop(scene,'LiquidBol',toggle = True,icon='MOD_FLUIDSIM')



class EasyLiquidOperator(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "object.easy_liquid"
    bl_label = "Easy Liquid"
    bl_space_type = ('VIEW_3D')
    bl_region_type = ('UI')
    bl_description = ("Liquids in one click")
    bl_options = {'REGISTER'}

    Reselution: bpy.props.IntProperty(
        name = "Reselution",
        default = 32,
        min = 1,
        max = 2048,
        soft_max = 256,
        description = "Detail of the whole simulation"
    )
    FlowType: bpy.props.EnumProperty(
        name = "Flow Type",
        items = [('INFLOW',"Inflow","Adds fluid to the simulation"),('GEOMETRY',"Fluid","The object becomes the fluid")],
        default = 'GEOMETRY',
        description = "Type of fluid object"
    )

    DomainScale: bpy.props.FloatVectorProperty(
        name = "Domain Scale",
        default = (1.0,1.0,3.0),
        min = 0.0,
        max = 1000.0,
        soft_max = 50.0,
        description = "Size of the whole simulation"
    )
    DomainLoc: bpy.props.FloatVectorProperty(
        name = "Domain Location",
        default = (1.0,1.0,3.0),
        min = -1000.0,
        max = 100.0,
        soft_max = 100.0,
        soft_min = -100.0,
        description = "Size of the whole simulation"
    )
    Name: bpy.props.StringProperty(
        name = "Name",
        default = "Fluid",
        description = "Name of the object",
    )
    Guide: bpy.props.BoolProperty(
        name = "Flow Controllers",
        default = False,
        description = "Makes the fluid follow the flow controllers"
    )
    Bake: bpy.props.BoolProperty(
        name = "Bake",
        default = True,
        description = "Makes the simulation permanent"
    )
    Start: bpy.props.IntProperty(
        name = "Start Frame",
        default = 0,
        min = 0,
        max = 10000,
        soft_max = 250
    )
    End: bpy.props.IntProperty(
        name = "End Frame",
        default = 50,
        min = 0,
        max = 10000,
        soft_max = 250
    )
    InVel: bpy.props.FloatVectorProperty(
        name = "Initial Velociety",
        default = (0,0,0),
        min = -5000,
        max = 5000,
        soft_min = -100,
        soft_max = 100,
        description = "Makes the inflow have an initial velocity, Only works if flow type is set to inflow"
    )

    @classmethod
    def poll(cls, context):
        return context.active_object is not None
    def invoke(self,context,event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        def EasyLiquidFunction(flowtype = 'INFLOW',domainloc = (0,0,-2),domainscale = (1,1,3),reselution = 32,bake=True,materials = True,mattype = 'water',start = 0, end = 250,guides = False,invel = (0,0,0)):
                bpy.ops.object.modifier_add(type='FLUID')
                bpy.context.object.modifiers["Fluid"].fluid_type = 'FLOW'
                bpy.context.object.modifiers["Fluid"].flow_settings.flow_type = 'LIQUID'
                bpy.context.object.modifiers["Fluid"].flow_settings.flow_behavior =flowtype
                if flowtype == 'INFLOW':
                    bpy.context.object.modifiers["Fluid"].flow_settings.use_initial_velocity = True
                    bpy.context.object.modifiers["Fluid"].flow_settings.velocity_coord = invel
                bpy.ops.mesh.primitive_cube_add(enter_editmode = True)
                bpy.context.object.name = "Domain"
                bpy.ops.transform.resize(value=domainscale, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False)
                bpy.ops.object.editmode_toggle()
                bpy.ops.object.modifier_add(type='FLUID')
                bpy.context.object.modifiers["Fluid"].fluid_type = 'DOMAIN'
                bpy.context.object.modifiers["Fluid"].domain_settings.domain_type = 'LIQUID'
                bpy.context.object.modifiers["Fluid"].domain_settings.resolution_max = reselution
                bpy.context.object.modifiers["Fluid"].domain_settings.use_mesh = True
                bpy.context.object.modifiers["Fluid"].domain_settings.timesteps_min = 4
                bpy.context.object.modifiers["Fluid"].domain_settings.timesteps_max = 7
                bpy.context.object.modifiers["Fluid"].domain_settings.cache_frame_start = start
                bpy.context.object.modifiers["Fluid"].domain_settings.cache_frame_end = end
                if guides:
                    bpy.context.object.modifiers["Fluid"].domain_settings.use_guide = True
                    bpy.context.object.modifiers["Fluid"].domain_settings.guide_source = 'EFFECTOR'
                if bake:
                    bpy.context.object.modifiers["Fluid"].domain_settings.cache_type = 'MODULAR'
                    if guides:
                        bpy.ops.fluid.bake_guides()
                    bpy.ops.fluid.bake_data()
                    bpy.ops.fluid.bake_mesh()



        EasyLiquidFunction(flowtype = self.FlowType,domainloc = self.DomainLoc,domainscale = self.DomainScale,reselution = self.Reselution,bake = self.Bake,materials = True,mattype = 'water',start = self.Start, end = self.End,guides=self.Guide,invel = self.InVel)
        return {'FINISHED'}




class MakeCollision(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "object.collision_make"
    bl_label = "Make Collision"
    bl_space_type = ('VIEW_3D')
    bl_region_type = ('UI')
    bl_description = ("Makes object a collision")
    bl_options = {'REGISTER','UNDO'}

    Thick: bpy.props.FloatProperty(
        name = "Thickness",
        min = 0,
        max = 1000,
        default = 0

    )


    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        bpy.ops.object.modifier_add(type='FLUID')
        bpy.context.object.modifiers["Fluid"].fluid_type = 'EFFECTOR'
        bpy.context.object.modifiers["Fluid"].effector_settings.effector_type = 'COLLISION'
        bpy.context.object.modifiers["Fluid"].effector_settings.surface_distance = self.Thick

        return {'FINISHED'}


class MakeGuide(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "object.guide_make"
    bl_label = "Make Flow Controller"
    bl_space_type = ('VIEW_3D')
    bl_region_type = ('UI')
    bl_description = ("Makes the fluid follow the object")
    bl_options = {'REGISTER','UNDO'}

    Thick: bpy.props.FloatProperty(
        name = "Thickness",
        min = 0,
        max = 1000,
        default = 0

    )
    Velocity: bpy.props.FloatProperty(
        name = "Velocity",
        default = 1,
        min = -1000,
        max = 1000,
        soft_min = -100,
        soft_max = 100,
        description = "Multiplies the speed of attraction",
        options = {'ANIMATABLE'}
    )
    Type: bpy.props.EnumProperty(
        items = [('OVERRIDE',"Override",""),('AVERAGED',"Averaged",""),('MINIMUM',"Minimize",""),('MAXIMUM',"Maximize","")],
        name = "Mode",
        default = 'OVERRIDE'
    )

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        bpy.ops.object.modifier_add(type='FLUID')
        bpy.context.object.modifiers["Fluid"].fluid_type = 'EFFECTOR'
        bpy.context.object.modifiers["Fluid"].effector_settings.effector_type = 'GUIDE'
        bpy.context.object.modifiers["Fluid"].effector_settings.surface_distance = self.Thick
        bpy.context.object.modifiers["Fluid"].effector_settings.velocity_factor = self.Velocity
        bpy.context.object.modifiers["Fluid"].effector_settings.guide_mode = self.Type



        return {'FINISHED'}



class EasyFluidMenu(bpy.types.Menu):
    bl_idname = 'object.easyfluid_menu'
    bl_label = "Easy Fluid"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_description = "Fluid simulation in just one click!"

    def draw(self,context):
        layout = self.layout

        layout.operator("object.easy_liquid",icon='MOD_OCEAN')
        layout.menu("object.Effector_Menu",icon='MATSHADERBALL')







class Effector_Menu(bpy.types.Menu):
    bl_idname = 'object.Effector_Menu'
    bl_label = "Make Effector"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_description = "Affects the simulation"

    def draw(self,context):
        layout = self.layout

        layout.operator("object.collision_make",icon='MOD_MASK')
        layout.operator("object.guide_make",icon='ANIM')

def add_menu_fluid(self,context):
    self.layout.menu("object.easyfluid_menu",icon='MOD_FLUIDSIM')




#================Panel=For=The=Addon=======================#


class EasyFluidPanel(bpy.types.Panel):
    bl_idname = "Easyfluid_Panel"
    bl_label = "Easy Fluid"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "EasyFluid"


    def draw(self,context):
        layout = self.layout

        row = layout.row()
        layout.label(text="Easy Fluid",icon='MOD_FLUIDSIM')

        row = layout.row()
        layout.label(text="This is an addon that simplifies fluid simulations",icon='MOD_OCEAN')

        row = layout.row()
        layout.label(text="To find this addon,")

        row = layout.row()
        layout.label(text="Go to the 3d view and look in the header find a menu marked EasyFluid",icon='SCENE_DATA')

        row = layout.row()
        layout.label(text="EasyLiquid creates a liquid simulation by using the selected object as a flow",icon='MOD_FLUID')

        row = layout.row()
        layout.label(text="")

        row = layout.row()
        layout.label(text="This menu creates effectors",icon='MATSHADERBALL')

        row = layout.row()
        layout.label(text="The flow controller makes the fluid follow the controller",icon='ANIM')

        row = layout.row()
        layout.label(text="The Collision makes the fluid collide with the object",icon='MOD_MASK')

#Make Properties


from bpy.props import IntProperty, FloatProperty, EnumProperty, BoolProperty, IntVectorProperty, FloatVectorProperty
bpy.types.Scene.Reselutionpan = 32
bpy.types.Scene.FlowTypepan = 'GEOMETRY'
bpy.types.Scene.DomainScalepan = (1,1,3)
bpy.types.Scene.DomainLocpan = (0,0,3)
bpy.types.Scene.efNamepan = "Fluid"
bpy.types.Scene.Guidepan = False
bpy.types.Scene.Bakepan = True
bpy.types.Scene.Startpan = 1
bpy.types.Scene.Endpan = 50
bpy.types.Scene.InVelpan = (0,0,0)
bpy.types.Scene.ThickcPan = 0
bpy.types.Scene.Velocityg = 1

def VelocityChange2(self,context):
    scene = context.scene
    if scene is not None:
        bpy.types.Scene.Velocityg = scene.Velocity

def ResChange(self,context):
    ob = context.scene
    if ob is not None:
        bpy.types.Scene.Reselutionpan = ob.Reselution + 1 - 1
        print(bpy.types.Scene.Reselutionpan)


def FlowChange(self,context):
    ob = context.scene
    bpy.types.Scene.FlowTypepan = ob.FlowType
    print(ob.FlowTypepan)

def ScaleChange(self,context):
    ob = context.scene
    if ob is not None:
        bpy.types.Scene.DomainScalepan = ob.DomainScale

def LocChange(self,context):
    ob = context.scene
    if ob is not None:
        bpy.types.Scene.DomainLocpan = ob.DomainLoc
        print(types.Scene.DomainLocpan)

def NameChange(self,context):
    ob = context.scene
    if ob is not None:
        bpy.types.Scene.efNamepan = ob.efName
def GuideChange(self,context):
    ob = context.scene
    if ob is not None:
        bpy.types.Scene.Guidepan = ob.Guide
def BakeChange(self,context):
    ob = context.scene
    if ob is not None:
        bpy.types.Scene.Bakepan = ob.Bake
def StartChange(self,context):
    ob = context.scene
    if ob is not None:
        bpy.types.Scene.Startpan = ob.Start
def EndChange(self,context):
    ob = context.scene
    if ob is not None:
        bpy.types.Scene.Endpan = ob.End
def InVelChange(self,context):
    ob = context.scene
    if ob is not None:
        bpy.types.Scene.InVelpan = ob.InVel
def ThickChangec(self,context):
    ob = context.scene
    if ob is not None:
        bpy.types.Scene.ThickcPan = ob.Thickc


bpy.types.Scene.Reselution = bpy.props.IntProperty(
    name = "Reselution",
    default = 32,
    min = 6,
    max = 2048,
    soft_max = 256,
    description = "Detail of the whole simulation",
    update = ResChange
)

bpy.types.Scene.FlowType = bpy.props.EnumProperty(
    name = "Flow Type",
    items = [('INFLOW',"Inflow","Adds fluid to the simulation"),('GEOMETRY',"Fluid","The object becomes the fluid")],
    default = 'GEOMETRY',
    description = "Type of fluid object",
    update = FlowChange
)

bpy.types.Scene.DomainScale = bpy.props.FloatVectorProperty(
    name = "Domain Scale",
    default = (1.0,1.0,3.0),
    min = 0.0,
    max = 1000.0,
    soft_max = 50.0,
    description = "Size of the whole simulation",
    update = ScaleChange
)
bpy.types.Scene.DomainLoc = bpy.props.FloatVectorProperty(
    name = "Domain Location",
    default = (1.0,1.0,3.0),
    min = -1000.0,
    max = 100.0,
    soft_max = 100.0,
    soft_min = -100.0,
    description = "Size of the whole simulation",
    update = LocChange
)
bpy.types.Scene.efName = bpy.props.StringProperty(
    name = "Name",
    default = "Fluid",
    description = "Name of the object",
    update = NameChange

)
bpy.types.Scene.Guide = bpy.props.BoolProperty(
    name = "Flow Controllers",
    default = False,
    description = "Makes the fluid follow the flow controllers",
    update = GuideChange
)
bpy.types.Scene.Bake = bpy.props.BoolProperty(
    name = "Bake",
    default = True,
    description = "Makes the simulation permanent",
    update = BakeChange
)
bpy.types.Scene.Start = bpy.props.IntProperty(
    name = "Start Frame",
    default = 0,
    min = 0,
    max = 10000,
    soft_max = 250,
    update = StartChange
)
bpy.types.Scene.End = bpy.props.IntProperty(
    name = "End Frame",
    default = 50,
    min = 0,
    max = 10000,
    soft_max = 250,
    update = EndChange
)
bpy.types.Scene.InVel = bpy.props.FloatVectorProperty(
    name = "Initial Velocity",
    default = (0,0,0),
    min = -5000,
    max = 5000,
    soft_min = -100,
    soft_max = 100,
    description = "Makes the inflow have an initial velocity, Only works if flow type is set to inflow",
    update = InVelChange
)

bpy.types.Scene.Thickc = bpy.props.FloatProperty(
    name = "Thickness",
    min = 0,
    max = 1000,
    default = 0,
    update = ThickChangec

)
bpy.types.Scene.Velocity = bpy.props.FloatProperty(
    name = "Velocity",
    default = 1,
    min = -1000,
    max = 1000,
    soft_min = -100,
    soft_max = 100,
    description = "Multiplies the speed of attraction",
    options = {'ANIMATABLE'},
    update = VelocityChange2
)

class EasyLiquidOperatorPan(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "object.easy_liquidpan"
    bl_label = "Easy Liquid"
    bl_space_type = ('VIEW_3D')
    bl_region_type = ('UI')
    bl_description = ("Liquids in one click")
    bl_options = {'REGISTER'}

    Reselution: bpy.props.IntProperty(
        name = "Reselution",
        default = 32,
        min = 1,
        max = 2048,
        soft_max = 256,
        description = "Detail of the whole simulation"
    )
    FlowType: bpy.props.EnumProperty(
        name = "Flow Type",
        items = [('INFLOW',"Inflow","Adds fluid to the simulation"),('GEOMETRY',"Fluid","The object becomes the fluid")],
        default = 'GEOMETRY',
        description = "Type of fluid object"
    )

    DomainScale: bpy.props.FloatVectorProperty(
        name = "Domain Scale",
        default = (1.0,1.0,3.0),
        min = 0.0,
        max = 1000.0,
        soft_max = 50.0,
        description = "Size of the whole simulation"
    )
    DomainLoc: bpy.props.FloatVectorProperty(
        name = "Domain Location",
        default = (1.0,1.0,3.0),
        min = -1000.0,
        max = 100.0,
        soft_max = 100.0,
        soft_min = -100.0,
        description = "Size of the whole simulation"
    )
    Name: bpy.props.StringProperty(
        name = "Name",
        default = "Fluid",
        description = "Name of the object",
    )
    Guide: bpy.props.BoolProperty(
        name = "Flow Controllers",
        default = False,
        description = "Makes the fluid follow the flow controllers"
    )
    Bake: bpy.props.BoolProperty(
        name = "Bake",
        default = True,
        description = "Makes the simulation permanent"
    )
    Start: bpy.props.IntProperty(
        name = "Start Frame",
        default = 0,
        min = 0,
        max = 10000,
        soft_max = 250
    )
    End: bpy.props.IntProperty(
        name = "End Frame",
        default = 50,
        min = 0,
        max = 10000,
        soft_max = 250
    )
    InVel: bpy.props.FloatVectorProperty(
        name = "Initial Velocity",
        default = (0,0,0),
        min = -5000,
        max = 5000,
        soft_min = -100,
        soft_max = 100,
        description = "Makes the inflow have an initial velocity, Only works if flow type is set to inflow"
    )

    @classmethod
    def poll(cls, context):
        return context.active_object is not None


    def execute(self, context):
        def EasyLiquidFunction(flowtype = 'INFLOW',domainloc = (0,0,-2),domainscale = (1,1,3),reselution = 32,bake=True,materials = True,mattype = 'water',start = 0, end = 250,guides = False,invel = (0,0,0),name="Fluid"):
                bpy.ops.object.modifier_add(type='FLUID')
                bpy.context.object.modifiers["Fluid"].fluid_type = 'FLOW'
                bpy.context.object.modifiers["Fluid"].flow_settings.flow_type = 'LIQUID'
                bpy.context.object.modifiers["Fluid"].flow_settings.flow_behavior =flowtype
                if flowtype == 'INFLOW':
                    bpy.context.object.modifiers["Fluid"].flow_settings.use_initial_velocity = True
                    bpy.context.object.modifiers["Fluid"].flow_settings.velocity_coord = invel
                bpy.ops.mesh.primitive_cube_add(enter_editmode = True)
                bpy.context.object.name = name
                bpy.ops.transform.resize(value=domainscale, orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False)
                bpy.ops.object.editmode_toggle()
                bpy.ops.object.modifier_add(type='FLUID')
                bpy.context.object.modifiers["Fluid"].fluid_type = 'DOMAIN'
                bpy.context.object.modifiers["Fluid"].domain_settings.domain_type = 'LIQUID'
                bpy.context.object.modifiers["Fluid"].domain_settings.resolution_max = reselution
                bpy.context.object.modifiers["Fluid"].domain_settings.use_mesh = True
                bpy.context.object.modifiers["Fluid"].domain_settings.timesteps_min = 4
                bpy.context.object.modifiers["Fluid"].domain_settings.timesteps_max = 7
                bpy.context.object.modifiers["Fluid"].domain_settings.cache_frame_start = start
                bpy.context.object.modifiers["Fluid"].domain_settings.cache_frame_end = end
                if guides:
                    bpy.context.object.modifiers["Fluid"].domain_settings.use_guide = True
                    bpy.context.object.modifiers["Fluid"].domain_settings.guide_source = 'EFFECTOR'
                if bake:
                    bpy.context.object.modifiers["Fluid"].domain_settings.cache_type = 'MODULAR'
                    if guides:
                        bpy.ops.fluid.bake_guides()
                    bpy.ops.fluid.bake_data()
                    bpy.ops.fluid.bake_mesh()



        EasyLiquidFunction(flowtype = bpy.types.Scene.FlowTypepan,domainloc = bpy.types.Scene.DomainLocpan,domainscale = bpy.types.Scene.DomainScalepan,reselution = bpy.types.Scene.Reselutionpan,bake = bpy.types.Scene.Bakepan,materials = True,mattype = 'water',start = bpy.types.Scene.Startpan, end = bpy.types.Scene.Endpan,guides=bpy.types.Scene.Guidepan,invel = bpy.types.Scene.InVelpan,name = bpy.types.Scene.efNamepan)
        return {'FINISHED'}

class MakeCollisionPan(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "object.collision_makepan"
    bl_label = "Make Collision"
    bl_space_type = ('VIEW_3D')
    bl_region_type = ('UI')
    bl_description = ("Makes object a collision")
    bl_options = {'REGISTER','UNDO'}

    Thick: bpy.props.FloatProperty(
        name = "Thickness",
        min = 0,
        max = 1000,
        default = 0

    )


    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        bpy.ops.object.modifier_add(type='FLUID')
        bpy.context.object.modifiers["Fluid"].fluid_type = 'EFFECTOR'
        bpy.context.object.modifiers["Fluid"].effector_settings.effector_type = 'COLLISION'
        bpy.context.object.modifiers["Fluid"].effector_settings.surface_distance = self.Thick

        return {'FINISHED'}





class EasyLiquidPanel(bpy.types.Panel):
    bl_idname = "EasyLiquid_Panel"
    bl_label = "Easy Liquid"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "EasyFluid"


    def draw(self,context):
        layout = self.layout
        object = context.scene

        row = layout.row()
        row.label(text="Easy Liquid",icon='MOD_OCEAN')

        row = layout.row()
        row.label(text="")

        row = layout.row()
        row.scale_y = 2
        row.operator("object.easy_liquidpan",icon='MOD_FLUIDSIM')

        row = layout.row()
        row.scale_y = 0.5
        row.label(text="")

        row = layout.row
        layout.prop(object,"Reselution")

        row = layout.row()
        layout.prop(object,"FlowType")

        split = layout.split(align=True)

        col = split.column()
        col.prop(object,"DomainScale")

        col = split.column()
        col.prop(object,"DomainLoc")

        row = layout.row()
        layout.prop(object,"efName")

        split = layout.split(align=True)

        col = split.column(align=True)
        col.prop(object,"Bake",toggle=True,icon='FREEZE')

        col = split.column(align=True)
        col.prop(object,"Guide",toggle=True,icon='ANIM')

        split = layout.split(align=True)

        col = split.column(align=True)
        col.prop(object,"Start")

        col = split.column(align=True)
        col.prop(object,"End")

        split = layout.split()
        col = split.column()
        col.prop(object,"InVel")


class EffectorPanel(bpy.types.Panel):
    bl_idname = "Effector_Panel"
    bl_label = "Make Effector"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "EasyFluid"

    def draw(self,context):
        scene = context.scene
        layout = self.layout

        row = layout.row()
        layout.label(text = "Make Collision",icon = 'MOD_MASK')

        row = layout.row()
        row.scale_y = 2
        row.operator("object.collision_make",icon = 'MOD_MASK').Thick = scene.Thickc

        row = layout.row()
        layout.prop(scene,"Thickc")

        row = layout.row()
        layout.label(text="")

        row = layout.row()
        layout.label(text="Make Flow Controller",icon='ANIM')

        row = layout.row()
        row.scale_y = 2
        row.operator("object.guide_make",icon="ANIM").Velocity = scene.Velocityg

        row = layout.row()
        layout.prop(scene,"Velocity")





#===========Register==================

def register():
    keys = bpy.context.window_manager.keyconfigs.addon
    bpy.utils.register_class(EasyLiquidOperator)
    bpy.utils.register_class(MakeCollision)
    bpy.utils.register_class(EasyLiquidOperatorPan)
    bpy.utils.register_class(MakeCollisionPan)
    bpy.utils.register_class(MakeGuide)
    bpy.utils.register_class(Effector_Menu)
    bpy.utils.register_class(EasyFluidMenu)
    bpy.utils.register_class(EasyFluidPreferences)
    bpy.utils.register_class(EasyFluidPanel)
    bpy.utils.register_class(EasyLiquidPanel)
    if bpy.types.Scene.EffPanup:
        bpy.utils.register_class(EffectorPanel)
    if bpy.types.Scene.AddonLocup == 'ADD':
        bpy.types.VIEW3D_MT_mesh_add.append(add_menu_fluid)
    else:
        bpy.types.VIEW3D_HT_header.append(add_menu_fluid)
    ky3d = keys.keymaps.new(name = '3d view', space_type = "VIEW_3D")
    Fluid_menu_call = ky3d.keymap_items.new(idname="wm.call_menu",type="E",value="PRESS",shift=True)
    Fluid_menu_call.properties.name = EasyFluidMenu.bl_idname





def unregister():
    bpy.utils.unregister_class(EasyLiquidOperator)
    bpy.utils.unregister_class(MakeCollision)
    bpy.utils.unregister_class(MakeCollisionPan)
    bpy.utils.unregister_class(EasyLiquidOperatorPan)
    bpy.utils.unregister_class(MakeGuide)
    bpy.utils.unregister_class(Effector_Menu)
    bpy.utils.unregister_class(EasyFluidMenu)
    bpy.utils.unregister_class(EasyFluidPanel)
    bpy.utils.unregister_class(EasyLiquidPanel)
    bpy.utils.unregister_class(EffectorPanel)
    if bpy.types.Scene.AddonLocup == 'ADD':
        bpy.types.VIEW3D_MT_mesh_add.remove(add_menu_fluid)
    else:
        bpy.types.VIEW3D_HT_header.remove(add_menu_fluid)
    bpy.utils.unregister_class(EasyFluidPreferences)



if __name__ == "__main__":
    register()

    # test call
